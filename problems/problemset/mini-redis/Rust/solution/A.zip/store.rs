use std::collections::{BTreeSet, HashMap, VecDeque};

#[derive(Clone, PartialEq)]
pub enum EType { Str, List, Set, ZSet }

pub struct Entry {
    pub etype:     EType,
    pub str_val:   String,
    pub list_val:  VecDeque<String>,
    pub set_val:   BTreeSet<String>,
    pub zset_val:  HashMap<String, f64>,
    pub expire_at: i64,
}

impl Entry {
    pub fn new(t: EType) -> Self {
        Entry {
            etype: t, str_val: String::new(), list_val: VecDeque::new(),
            set_val: BTreeSet::new(), zset_val: HashMap::new(), expire_at: -1,
        }
    }
}

pub struct Store {
    data:    HashMap<String, Entry>,
    pub now: i64,
}

impl Store {
    pub fn new() -> Self { Store { data: HashMap::new(), now: 0 } }

    fn dead(&self, k: &str) -> bool {
        match self.data.get(k) {
            None    => true,
            Some(e) => e.expire_at >= 0 && e.expire_at <= self.now,
        }
    }

    pub fn alive(&mut self, k: &str) -> bool {
        if self.dead(k) { self.data.remove(k); false } else { true }
    }

    pub fn get(&mut self, k: &str) -> Option<&Entry> {
        if self.dead(k) { self.data.remove(k); None } else { self.data.get(k) }
    }

    pub fn get_mut(&mut self, k: &str) -> Option<&mut Entry> {
        if self.dead(k) { self.data.remove(k); None } else { self.data.get_mut(k) }
    }

    pub fn make(&mut self, k: &str, t: EType) -> &mut Entry {
        if self.dead(k) {
            self.data.remove(k);
            self.data.insert(k.to_string(), Entry::new(t));
        } else if !self.data.contains_key(k) {
            self.data.insert(k.to_string(), Entry::new(t));
        }
        self.data.get_mut(k).unwrap()
    }

    pub fn reset(&mut self, k: &str) -> &mut Entry {
        self.data.insert(k.to_string(), Entry::new(EType::Str));
        self.data.get_mut(k).unwrap()
    }

    pub fn erase(&mut self, k: &str) { self.data.remove(k); }
    pub fn flush(&mut self) { self.data.clear(); }
    pub fn tick(&mut self, n: i64) { self.now += n; }
    pub fn time(&self) -> i64 { self.now }

    pub fn dbsize(&mut self) -> i64 {
        let keys: Vec<String> = self.data.keys().cloned().collect();
        keys.iter().filter(|k| self.alive(k)).count() as i64
    }
}
