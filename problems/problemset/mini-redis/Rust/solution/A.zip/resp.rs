use std::io::{BufRead, BufReader, Write};
use std::net::TcpStream;

pub fn read_cmd(r: &mut BufReader<TcpStream>) -> Option<Vec<String>> {
    let mut line = String::new();
    r.read_line(&mut line).ok()?;
    let line = line.trim_end_matches(|c| c == '\r' || c == '\n');
    if !line.starts_with('*') { return None; }
    let argc: usize = line[1..].parse().ok()?;
    let mut args = Vec::with_capacity(argc);
    for _ in 0..argc {
        let mut blen = String::new();
        r.read_line(&mut blen).ok()?;
        let blen = blen.trim_end_matches(|c| c == '\r' || c == '\n');
        if !blen.starts_with('$') { return None; }
        let n: usize = blen[1..].parse().ok()?;
        let mut buf = vec![0u8; n + 2];
        use std::io::Read;
        r.read_exact(&mut buf).ok()?;
        args.push(String::from_utf8_lossy(&buf[..n]).to_string());
    }
    Some(args)
}

pub fn w(c: &mut TcpStream, s: &str)           { c.write_all(s.as_bytes()).ok(); }
pub fn simple(c: &mut TcpStream, s: &str)      { w(c, &format!("+{}\r\n", s)); }
pub fn rerr(c: &mut TcpStream, s: &str)        { w(c, &format!("-{}\r\n", s)); }
pub fn rint(c: &mut TcpStream, n: i64)         { w(c, &format!(":{}\r\n", n)); }
pub fn rnil(c: &mut TcpStream)                 { w(c, "$-1\r\n"); }
pub fn earr(c: &mut TcpStream)                 { w(c, "*0\r\n"); }
pub fn bulk(c: &mut TcpStream, s: &str)        { w(c, &format!("${}\r\n{}\r\n", s.len(), s)); }

pub fn arr(c: &mut TcpStream, items: &[String]) {
    w(c, &format!("*{}\r\n", items.len()));
    for item in items { bulk(c, item); }
}

pub fn fmt_g(f: f64) -> String {
    if f.fract() == 0.0 && f.abs() < 1e15 { format!("{}", f as i64) }
    else { format!("{}", f) }
}
