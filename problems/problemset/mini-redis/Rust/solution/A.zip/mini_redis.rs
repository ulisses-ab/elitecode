mod store;
mod resp;
mod dispatch;

use std::io::BufReader;
use std::net::TcpListener;

pub struct MiniRedis {
    store: store::Store,
}

impl MiniRedis {
    pub fn new() -> Self { MiniRedis { store: store::Store::new() } }

    pub fn start(&mut self, port: u16) {
        let listener = TcpListener::bind(("0.0.0.0", port)).unwrap();
        for stream in listener.incoming() {
            let Ok(stream) = stream else { continue };
            let reader_stream = stream.try_clone().unwrap();
            let mut writer = stream;
            let mut reader = BufReader::new(reader_stream);
            loop {
                match resp::read_cmd(&mut reader) {
                    None       => break,
                    Some(args) => dispatch::dispatch(&mut self.store, &mut writer, &args),
                }
            }
        }
    }
}
